package com.java.otp;

public enum Gender {
	
	MALE,FEMALE

}
