package com.java.otp;

public enum Type {
	
	DOCTOR, OWNER

}
