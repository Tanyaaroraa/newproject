package com.java.otp;

import java.util.Random;

public class ForgotPasswordTest {

    public static void main(String[] args) {
        Provider_Authentication provider = new Provider_Authentication();
        provider.setUsername("john_doe");
        provider.setProviderid("12345");
        provider.setEmail("example1@example.com");

        ProviderAuthenticationDaoImpl providerDAO = new ProviderAuthenticationDaoImpl();

        Provider_Authentication providerFound = providerDAO.findProviderByIdUsernameOrEmail(provider.getEmail());
        String result = "User Not Found";
        if (providerFound != null) {
            String otp = generateOTP(); 
            provider.setOtp(otp);
            result = "Reset Key Sent To Email..."; 
            System.out.println(otp);
        }

        System.out.println(result);
        
    }

    
    private static String generateOTP() {
        Random random = new Random();
        int otpValue = 100000 + random.nextInt(900000);
        return String.valueOf(otpValue);
    }
	
}
