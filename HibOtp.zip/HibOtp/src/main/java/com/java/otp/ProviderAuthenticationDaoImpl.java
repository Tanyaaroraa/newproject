package com.java.otp;

import java.util.Map;
import java.util.Random;

import javax.faces.context.FacesContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class ProviderAuthenticationDaoImpl {
	SessionFactory sf;

	Session session;
	
	private String generateOTP() {
        Random random = new Random();
        int otpValue = 100000 + random.nextInt(900000);
        return String.valueOf(otpValue);
    }
	
	
	public Provider_Authentication findProviderByIdUsernameOrEmail(String input) {
		Provider_Authentication provider = new Provider_Authentication();
		SessionFactory sf = SessionHelper.getConnection();
		Session session =sf.openSession();
		//Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		 Query query = session.createQuery(
	                "FROM Provider_Authentication WHERE providerid = :input OR username = :input OR email = :input"
	            );
		 query.setParameter("input", input);

         provider = (Provider_Authentication) query.uniqueResult();
        // sessionMap.put("provider", provider);
		
         return provider;
	
	}
	
	
	public String forgotPassword(Provider_Authentication provider) {
		String input = provider.getUsername();
		input = provider.getProviderid();
		input =  provider.getEmail();
		Provider_Authentication providerfound = findProviderByIdUsernameOrEmail(input);
		
		

		
		
        if (provider != null) {
            String otp = generateOTP(); // Generate a new OTP
            provider.setOtp(otp);
            System.out.println(otp);
            
            session.beginTransaction();
            session.update(provider);
            session.getTransaction().commit();

    
        
        String body = "Welcome to Mr/Miss " + providerfound.getUsername() + "\r\n" +
                "Your Reset Key Generated Successfully..." + "\r\n" +
                "Reset Key is " + otp;
        MailSend.mailOtp(providerfound.getEmail(), "Otp Send Successfully...", body);
        
        return "Reset Key Sent To Email...";
        }
	return "User Not Found";
}
}


		       


