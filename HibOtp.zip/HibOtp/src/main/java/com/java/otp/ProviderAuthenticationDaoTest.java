package com.java.otp;

public class ProviderAuthenticationDaoTest {

    public static void main(String[] args) {
        ProviderAuthenticationDaoImpl dao = new ProviderAuthenticationDaoImpl();

        String userInput = "example@example.com"; 

        Provider_Authentication provider = dao.findProviderByIdUsernameOrEmail(userInput);

        if (provider != null) {
            
            System.out.println("Provider found:");
            System.out.println("Provider ID: " + provider.getProviderid()); 
            System.out.println("Username: " + provider.getUsername()); 
            System.out.println("Email: " + provider.getEmail()); 
        } else {
            
            System.out.println("Provider not found for input: " + userInput);
        }
    }
}
